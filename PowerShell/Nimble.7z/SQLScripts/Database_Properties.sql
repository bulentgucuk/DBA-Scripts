DECLARE @command varchar(1000) 

--Set Recovery Full
SELECT @command = 'USE ?
IF DB_ID(''?'') > 4
BEGIN
 print ''?'' + '': SET RECOVERY FULL WITH NO_WAIT''
 EXEC sp_executesql N''ALTER DATABASE [?] SET RECOVERY FULL WITH NO_WAIT'';
END'
EXEC sp_MSforeachdb @command

--Set Recovery Simple
SELECT @command = 'USE ?
IF DB_ID(''?'') > 4
BEGIN
 print ''?'' + '': SET RECOVERY SIMPLE WITH NO_WAIT''
 EXEC sp_executesql N''ALTER DATABASE [?] SET RECOVERY SIMPLE WITH NO_WAIT'';
END'
EXEC sp_MSforeachdb @command

--set db owner to sa
SELECT @command = 'USE ?
IF DB_ID(''?'') > 4 AND ''?'' NOT IN (''distribution'')
BEGIN 
	print ''?'' + '' - Change DB Owner''
	EXEC sp_executesql N''sp_changedbowner ''''sa'''', ''''false'''';''
END'
EXEC sp_MSforeachdb @command

--shrink log files
SELECT @command = 'USE ?
	DECLARE @ln varchar(100) 
	SET @ln=(SELECT name FROM [?].dbo.sysfiles WHERE fileid=2) USE [?] DBCC SHRINKFILE (@ln, 0)'
EXEC sp_MSforeachdb @command