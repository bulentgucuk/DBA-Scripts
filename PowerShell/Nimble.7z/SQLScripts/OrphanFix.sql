EXEC sp_MSforeachdb 'USE ?
DECLARE @UserCount INT
DECLARE @UserCurr INT
DECLARE @userName VARCHAR(100)
DECLARE @vsql NVARCHAR(4000)
DECLARE @Users TABLE(id INT IDENTITY(1,1) PRIMARY KEY NOT NULL,userName VARCHAR(100),UserSid varchar(max))
INSERT INTO @Users(UserName,UserSid) EXEC sp_change_users_login ''Report''

SELECT @UserCount = isnull(max([id]),0) FROM @Users
SET @UserCurr = 1

WHILE (@UserCurr <= @UserCount)
BEGIN
 SELECT @userName = userName FROM @Users WHERE [id] = @UserCurr
 IF EXISTS (SELECT 1 FROM master.sys.server_principals WHERE name = @userName)
 BEGIN
   SET @vsql = ''[dbo].[sp_change_users_login] ''''AUTO_FIX'''','' + '''''''' + @userName + '''''''' + ''''
   PRINT @vsql
   EXEC(@vsql)
 END
 ELSE
 BEGIN
	PRINT ''No Login.  Skipping user '' + @userName + '' exists in '' + ''?'' 
 END
 SET @UserCurr = @UserCurr + 1
END'
