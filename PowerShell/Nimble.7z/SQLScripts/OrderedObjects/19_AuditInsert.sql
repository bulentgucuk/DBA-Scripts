USE [Audit]
GO
Declare @ID bigint
Declare @Currentdate date = getdate()
select top 1 @ID =  [ToolbarClickLogId]
from Reportsql.SystemLogging.[dbo].[ToolbarClickLog] with(nolock)
where createdate > @Currentdate
order by 1 




INSERT INTO [dbo].[StagingAudit]
           ([PackageName]
           ,[StartDateTime]
           ,[EndDateTime]
           ,[ExecutionInstanceGUID]
           ,[ParentExecutionInstanceGUID]
           ,[SourceTableName]
           ,[DestinationTableName]
           ,[AuditStatusDesc]
           ,[SourceRowCount]
           ,[InsertRowCount]
           ,[SourceBeginningIdentity]
           ,[SourceEndingIdentity]
           ,[SourceMinDateTime]
           ,[SourceMaxDateTime])
     VALUES
           ('stgToolbarClickLog'
           ,getdate()
           ,getdate()
           ,'{B8F45D14-25C1-4F00-A98E-B86717580505}'
           ,'{B8F45D14-25C1-4F00-A98E-B86717580505}'
           ,'stgToolbarClickLog'
           ,'stgToolbarClickLog'
           ,'False Entry - used to start staging'
           ,0
           ,0
           ,0
           ,@ID --Change to identity for that day
           ,getdate()
           ,getdate())
GO