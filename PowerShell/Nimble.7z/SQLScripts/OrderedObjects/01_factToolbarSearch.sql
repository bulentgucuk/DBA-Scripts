USE [DataMart]
GO

/****** Object:  Table [dbo].[ToolbarSearch]    Script Date: 11/19/2013 11:28:32 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[factToolbarSearch]') AND type in (N'U'))
BEGIN

CREATE TABLE [dbo].[factToolbarSearch](
	[ToolbarClickLogID] [int] NULL,
	[MerchantSK] [int] NULL,
	[MerchantID] [int] NULL,
	[MerchantName] [nvarchar](75) NULL,
	[CustomerID] [int] NULL,
	[CreateDate] [datetime] NULL,
	[ReferCodeSK] [int] NULL,
	[ReferCode] [int] NULL,
	[ToolbarReferCodeSK] [int] NULL,
	[ToolbarReferCode] [int] NULL,
	[ToolBarAlertID] [int] NULL,
	[ToolbarAlertTypeID] [int] NULL,
	[ToolbarAlertType] [varchar](15) NULL,
	[AppVersion] [varchar](11) NULL,
	[SearchTerm] [nvarchar](100) NULL,
	[BrowserSK] [int] NULL,
	[BrowserName] [nvarchar](35) NULL,
	[BrowserVersion] [nvarchar](7) NULL,
	[DWCreateDate] [smalldatetime] NULL,
	[DWLastUpdateDate] [smalldatetime] NULL
) ON [PRIMARY]
END
GO


SET ANSI_PADDING OFF
GO


