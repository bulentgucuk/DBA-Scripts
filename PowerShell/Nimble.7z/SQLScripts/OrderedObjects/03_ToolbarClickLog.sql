USE [Staging]
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[PRODODS].[ToolbarClickLog]') AND type in (N'U'))
BEGIN
CREATE TABLE [PRODODS].[ToolbarClickLog](
	[ToolbarClickLogId] [int] NOT NULL,
	[MerchantId] [int] NOT NULL,
	[CustomerId] [int] NOT NULL,
	[CreateDate] [datetime] NOT NULL,
	[Refercode] [int] NULL,
	[ToolbarRefercode] [int] NULL,
	[ToolbarAlertID] [int] NULL,
	[ToolbarAlertTypeID] [int] NULL,
	[ToolbarVersion] [varchar](50) NULL,
	[SearchTerm] [nvarchar](100) NULL,
	[BrowserType] [varchar](50) NULL,
	[BrowserName] [varchar](35) NULL,
	[BrowserVersion] [varchar](7) NULL
) ON [PRIMARY]

END