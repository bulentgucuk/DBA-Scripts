USE [Staging]
GO

/****** Object:  StoredProcedure [SAHDelete].[delToolbarClickLog]    Script Date: 11/6/2013 11:08:45 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('[SAHDelete].[delToolbarClickLog]', 'P') is NOT NULL
Drop proc [SAHDelete].[delToolbarClickLog]
GO
CREATE proc [SAHDelete].[delToolbarClickLog]
With Execute as owner
as
TRUNCATE Table Staging.PRODODS.ToolbarClickLog

GO


