USE [DataWarehouse]
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ToolbarSearch]') AND type in (N'U'))
BEGIN

CREATE TABLE dbo.ToolbarSearch
(
	ToolbarClickLogID int
	, MerchantSK int
	, MerchantID int
	, MerchantName nvarchar(75)
	, CustomerID int
	, CreateDate datetime
	, ReferCodeSK int
	, ReferCode int
	, ToolbarReferCodeSK int
	, ToolbarReferCode int
	, ToolBarAlertID int
	, ToolbarAlertTypeID int
	, ToolbarAlertType varchar(15)
	, AppVersion varchar(11)
	, SearchTerm nvarchar(100)
	, BrowserSK int
	, BrowserName nvarchar(35)
	, BrowserVersion nvarchar(7)
	, DWCreateDate smalldatetime
	, DWLastUpdateDate smalldatetime
)

END