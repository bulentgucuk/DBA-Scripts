 USE [DataWarehouse]
 GO
 
 INSERT INTO Browser
  ([BrowserName]
      ,[BrowserVersion]
      ,[CreateDate]
      ,[DWEffectiveDate]
      ,[DWObsoleteDate]
      ,[DWIsInferred]
      ,[DWCreateDate]
      ,[DWLastUpdateDate])
	  VALUES ('Firefox', '', NULL, getdate(), NULL, 0, getdate(), getdate())

 INSERT INTO Browser
  ([BrowserName]
      ,[BrowserVersion]
      ,[CreateDate]
      ,[DWEffectiveDate]
      ,[DWObsoleteDate]
      ,[DWIsInferred]
      ,[DWCreateDate]
      ,[DWLastUpdateDate])
	  VALUES ('Chrome', '', NULL, getdate(), NULL, 0, getdate(), getdate())

 INSERT INTO Browser
  ([BrowserName]
      ,[BrowserVersion]
      ,[CreateDate]
      ,[DWEffectiveDate]
      ,[DWObsoleteDate]
      ,[DWIsInferred]
      ,[DWCreateDate]
      ,[DWLastUpdateDate])
	  VALUES ('Internet Explorer', '', NULL, getdate(), NULL, 0, getdate(), getdate())

 INSERT INTO Browser
  ([BrowserName]
      ,[BrowserVersion]
      ,[CreateDate]
      ,[DWEffectiveDate]
      ,[DWObsoleteDate]
      ,[DWIsInferred]
      ,[DWCreateDate]
      ,[DWLastUpdateDate])
	  VALUES ('Safari', '', NULL, getdate(), NULL, 0, getdate(), getdate())