USE [MasterData]
GO

/****** Object:  Table [dbo].[ToolbarAlertType]    Script Date: 11/13/2013 8:51:30 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ToolbarAlertType]') AND type in (N'U'))
BEGIN

CREATE TABLE [dbo].[ToolbarAlertType](
	[ToolbarAlertTypeID] [int] NOT NULL,
	[AlertType] [varchar](15) NOT NULL,
	[AlertTypeDescription] [varchar](50) NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO


