USE [Staging]
GO
IF OBJECT_ID('SAHRead.getStageToolbarSearch', 'P') is NOT NULL
Drop proc SAHRead.getStageToolbarSearch
GO
CREATE PROCEDURE SAHRead.getStageToolbarSearch

AS

SELECT tcl.[ToolbarClickLogId]
      ,tcl.[MerchantId]
	  ,m.MerchantSK
	  ,m.MerchantName
      ,tcl.[CustomerId]
      ,tcl.[CreateDate]
      ,tcl.[Refercode]
	  ,rc.ReferCodeSK
      ,tcl.[ToolbarRefercode]
	  ,rc2.ReferCodeSK as ToolbarRefercodeSK
      ,tcl.[ToolbarAlertID]
      ,tcl.[ToolbarAlertTypeID]
	  ,tat.AlertType as ToolbarAlertType
      ,CASE
		WHEN LEN(tcl.ToolbarVersion) = 0 THEN 'Unspecified'
		ELSE tcl.[ToolbarVersion] 
		END as AppVersion
      ,isNULL(tcl.[SearchTerm], '') as SearchTerm
	  ,b.BrowserSK
      ,CAST(tcl.BrowserName as nvarchar) as BrowserName
	  ,CASE
		WHEN LEN(tcl.BrowserVersion) = 0 THEN CAST('0.0' as nvarchar)
		ELSE CAST(tcl.BrowserVersion as nvarchar)
		END as BrowserVersion
  FROM [PRODODS].[ToolbarClickLog] tcl with(nolock)
  LEFT JOIN DataWarehouse.dbo.ReferCode rc ON rc.ReferCode = tcl.Refercode
  LEFT JOIN DataWarehouse.dbo.ReferCode rc2 ON rc2.ReferCode = tcl.ToolbarRefercode
  LEFT JOIN DataWarehouse.dbo.Merchant m ON m.MerchantID = tcl.MerchantId
  LEFT JOIN MasterData.dbo.ToolbarAlertType tat ON tat.ToolbarAlertTypeID = tcl.ToolbarAlertTypeID
  LEFT JOIN Datawarehouse.dbo.Browser b ON ((CAST(tcl.browserVersion as nvarchar)) = b.BrowserVersion AND (CAST(tcl.BrowserName as nvarchar)) = b.BrowserName )
  WHERE tcl.Refercode = 85515 --Only ribbon searches
  AND LEN(tcl.SearchTerm) > 0
GO



