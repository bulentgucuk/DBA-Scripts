﻿function RunSQLScripts {
    #If environment doesn't use the script have a placeholder file
    #moved to after replication is dropped
    #Write-Host "Restore AppMgmt Database"
    #Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Parent\SQLScripts\AppMgmtRestore.sql" -querytimeout 600 -verbose
    Write-Host "Run Cleanup Script"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Parent\SQLScripts\CleanupScript.sql" -querytimeout 600 -verbose
    Write-Host "Restore Security Changes - SAH\QA"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Parent\SQLScripts\Security.sql" -querytimeout 600 -verbose 
    Write-Host "Restore Security Changes - DEV"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Parent\SQLScripts\Security_DEV.sql" -querytimeout 600 -verbose 
    Write-Host "Restore Security Changes - MKTG"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Parent\SQLScripts\Security_MKTG.sql" -querytimeout 600 -verbose 
    Write-Host "Restore Security Changes - AutomationUser"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Parent\SQLScripts\AutomationUser.sql" -querytimeout 600 -verbose 
    Write-Host "Reseed Customer"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Parent\SQLScripts\Reseed.sql" -querytimeout 600 -verbose
    Write-Host "Set Database Properties"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Parent\SQLScripts\Database_Properties.sql" -querytimeout 600 -verbose
    Write-Host "Owner Fix"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Parent\SQLScripts\Owner.sql" -querytimeout 600 -verbose 
    Write-Host "Orphan User Fix"
    $ErrorCount = $error.count
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Parent\SQLScripts\OrphanFix.sql" -querytimeout 600 -verbose -ErrorAction SilentlyContinue
    #If the orphan fix can't fix the issue it reports a false error.
    if ($ErrorCount -eq 0 -and $error.count -ne 0) {
        Write-Host "Clear Orphan User False Error"
        $error.Clear()
    }
    #Write-Host "Replication Fix"
    #Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Parent\SQLScripts\Replication.sql" -querytimeout 600 -verbose    

    if ($DW -eq "true") {
      Start-Sleep -s 10
      #Update DDL and DML for DEV BI Environment
      Write-Host "Update DDL and DML for $SQLInstance Environment Specific requirements"
      Get-ChildItem -path "$Parent\SQLScripts\OrderedObjects" -Filter "*.sql"| %{invoke-sqlcmd -InputFile $_.FullName -ServerInstance $FullSQL}
      foreach ($f in Get-ChildItem -path "$Parent\SQLScripts\OrderedObjects" -Filter *.sql | sort-object) 
      {
        $out = "$Parent\SQLScripts\OrderedObjects\" + $f.name.split(".")[0] + ".txt" ;
        write-host $f
        invoke-sqlcmd –ServerInstance $FullSQL -InputFile $f.fullname | format-table | out-file -filePath $out
      }
      Invoke-SqlCmd -InputFile "$Parent\SQLScripts\biteam.sql" -ServerInstance $FullSQL -querytimeout 600 -verbose
    }
}



####MAIN###
Import-Module sqlps –DisableNameChecking
RunSQLScripts
