﻿function StopSQL {
    #Shutdown SQL Services
    foreach($service in $services) {
    Write-Host "Stopping SQL service " $service.Name
        Stop-Service -Force -Name $service.Name
        Start-Sleep -s 10
    }
}

function DeleteVolume ($SQLVolume) {
    if ($SQLVolume -ne "") {  
        Write-Host "Delete Volume " $SQLVolume
        Remove-NSVolume $SQLVolume -force 
    }
}

function CloneVolume ($ProdVolume, $SQLVolume) {
    if ($ProdVolume -ne "") { 
        Write-Host "Clone Volume " $ProdVolume 
        Get-NSSnapShot $ProdVolume |where-object {$_.schedulename -eq $ScheduleName} |sort-Object -Property LocalCreationTime -Descending | Select -First 1 | New-NSClone -Name $SQLVolume 
        Add-NSInitiatorGroupToVolume -InitiatorGroup $InitiatorGroup -Volume $SQLVolume -Access Volume
    } 

    $error.Clear()  #above lines produced a few divide by zero errors but appears to be working fine?
}

function RefreshiSCSI {
    # Refresh iSCSI Targets
    Write-Host "Refreshing to find new targets"
    Refresh-Targets

    # Get Available Nimble Targets
    $NimbleTargets = Get-AvailableTargets | ? {$_.Target -notmatch "com.nimblestorage:control-"} | ? {$_.Target -match "com.nimblestorage"} | Sort-Object -Unique Target
    Write-Host "Found " $NimbleTargets.Count " Nimble targets"

    # Loop through each Nimble target and host IP and validate connections. If any are missing, execute iscsicli to connect and make persistent 
    Write-Host "Removing all old Nimble persistent iSCSI logins"
    foreach ($Login in Get-PersistentLogins | ? {$_.Target -match "com.nimblestorage"}) {
      if ($Login.Target -eq $null) {
        continue
      }
      iscsicli removepersistenttarget $Login.Initiator $Login.Target $Login.InitiatorPort $Login.TargetIP $Login.TargetPort | Out-Null
    }

    foreach ($Target in $NimbleTargets) {
      Write-Host "Connecting to " $Target.Target
      Connect-toIQN $Target.Target
    }
}

function ConnectDisks {
    # Wait 5 seconds for connections to finalize
    Write-Host "Rescanning for new drives"
    "rescan `n exit" | diskpart | out-null
    Start-Sleep -s 10

    # Get current set of Nimble sessions
    #$NimbleDisks = Get-EstablishedSessions | ? {$_.Target -match "com.nimblestorage"} | ? {$_.Target -match $env:COMPUTERNAME + "-" + $SQLInstance } | Select Target,TargetNice,Devices -Unique
    $NimbleDisks = Get-EstablishedSessions | Select Target,TargetNice,Devices -Unique

    # Loop Nimble Disks and make sure they are online and mount if not already mounted
    foreach ($NimbleDisk in $NimbleDisks) {
      Write-Host "Setting " $NimbleDisk.TargetNice " online"
      "select disk "+$NimbleDisk.Devices[0].DeviceNumber+"`n attributes disk clear readonly noerr`n online `n online disk" | diskpart | out-null
      $Disk = Get-WmiObject -Class Win32_DiskDrive | ? {$_.Caption -match "Nimble Server" -and $_.DeviceID -eq $NimbleDisk.Devices[0].LegacyName}
      $Partitions = Get-WmiObject -Query "ASSOCIATORS OF {$($Disk.Path.RelativePath)}" | ? {$_.__CLASS -eq "Win32_DiskPartition"}
      foreach ($Partition in $Partitions) {
	    $PathMount = "$Path\"+$NimbleDisk.TargetNice+"\"+$Partition.Index
	    if(Test-Path -Path $PathMount -PathType Container) {
	      mountvol $PathMount /d
	    }
	    else {
	      #New-Item $Path -ItemType Directory | Out-Null
	    }

  	    Write-Host "Mounting " $NimbleDisk.TargetNice " @ " $Path
	    "select disk "+$NimbleDisk.Devices[0].DeviceNumber+"`n select partition "+$($Partition.Index + 1)+"`n attributes volume clear readonly noerr`n attributes volume clear hidden noerr`n attributes volume clear shadowcopy noerr`n assign mount="+$Path | diskpart
	    "select disk "+$NimbleDisk.Devices[0].DeviceNumber+"`n select partition "+$($Partition.Index + 1)+"`n attributes volume clear readonly noerr`n attributes volume clear hidden noerr`n attributes volume clear shadowcopy noerr`n assign mount="+$Path | diskpart
	    chkdsk /x $Path | out-null
      }
    }

    Start-Sleep -s 30
}

function StartSQL {
    # Restart SQL Services
    foreach($service in $services) {
     if((Get-WmiObject Win32_Service -filter ("Name='"+$service.Name+"'")).StartMode -eq "Auto") {
      Write-Host "Starting SQL service " $service.Name
      Start-Service -Name $service.Name
     }
    }
    Start-Sleep -s 30
}

function RunSQLScripts {
    #If environment doesn't use the script have a placeholder file
    Write-Host "Restore AppMgmt Database"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Path\Scripts\AppMgmtRestore.sql" -querytimeout 600 -verbose
    Write-Host "Run Cleanup Script"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Path\Scripts\CleanupScript.sql" -querytimeout 600 -verbose
    Write-Host "Restore Security Changes - SAH\QA"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Path\Scripts\Security.sql" -querytimeout 600 -verbose 
    Write-Host "Restore Security Changes - DEV"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Path\Scripts\Security_DEV.sql" -querytimeout 600 -verbose 
    Write-Host "Restore Security Changes - MKTG"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Path\Scripts\Security_MKTG.sql" -querytimeout 600 -verbose 
    Write-Host "Restore Security Changes - AutomationUser"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Path\Scripts\AutomationUser.sql" -querytimeout 600 -verbose 
    Write-Host "Reseed Customer"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Path\Scripts\Reseed.sql" -querytimeout 600 -verbose
    Write-Host "Set Database Properties"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Path\Scripts\Database_Properties.sql" -querytimeout 600 -verbose
    Write-Host "Orphan User Fix"
    $ErrorCount = $error.count
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Path\Scripts\OrphanFix.sql" -querytimeout 600 -verbose -ErrorAction SilentlyContinue
    #If the orphan fix can't fix the issue it reports a false error.
    if ($ErrorCount -eq 0 -and $error.count -ne 0) {
        Write-Host "Clear Orphan User False Error"
        $error.Clear()
    }

    if ($DW -eq "true") {
      Start-Sleep -s 10
      #Update DDL and DML for DEV BI Environment
      Write-Host "Update DDL and DML for $SQLInstance Environment Specific requirements"
      Get-ChildItem -path "$Path\Scripts\OrderedObjects" -Filter "*.sql"| %{invoke-sqlcmd -InputFile $_.FullName -ServerInstance $FullSQL}
      foreach ($f in Get-ChildItem -path "$Path\Scripts\OrderedObjects" -Filter *.sql | sort-object) 
      {
        $out = "$Path\Scripts\OrderedObjects\" + $f.name.split(".")[0] + ".txt" ;
        write-host $f
        invoke-sqlcmd –ServerInstance $FullSQL -InputFile $f.fullname | format-table | out-file -filePath $out
      }
      Invoke-SqlCmd -InputFile "$Path\Scripts\biteam.sql" -ServerInstance $FullSQL -querytimeout 600 -verbose
    }
}

function SendEmails {
    if ($error.count -eq 0) {
	    [string]$Subject = "Success: $SQLInstance Refresh had been Applied"
	    [string]$EmailBody = "Refresh Complete"
	    
	    $email = @{
		    From = $From
		    To = $GroupToArray
		    Subject = $Subject 
		    SMTPServer = $SMTP
		    Body = $EmailBody
	    }

        #Notify XYZ Group the refresh was completed with success (As long as it is not a test/dba manual run) 
        if ($Test -eq "false") {	    
            Write-Host "Sending Email to " $GroupTo
            #send-mailmessage @email 
        }
	    $EmailBody = (Get-Content -Path $LogFile -raw)
    }
    Else {
	    [string]$EmailBody = $error
	    [string]$Subject = "Failure: $SQLInstance Refresh Error"
    } 

    Write-Host "Sending Email to " $To
    #dba notify
    $email = @{
      From = $From
      To = $ToArray
      Subject = $Subject 
      SMTPServer = $SMTP
      Body = $EmailBody
    }
    send-mailmessage @email
}

####MAIN###
cls
#Import Modules/Cmdlets
#https://gallery.technet.microsoft.com/scriptcenter/Enhanced-Script-Logging-27615f85
Import-Module PowerShellLogging 
Import-Module Nimble
Import-Module 'sqlps' –DisableNameChecking
. ("C:\Windows\System32\WindowsPowerShell\v1.0\Modules\Nimble\iSCSI_Cmdlets.ps1")

$Path  = "c:\nimble" #[System.Environment]::CurrentDirectory
$LogFile = "$Path\Logs\$(get-date -f yyyy-MM-dd).log"
$Log = Enable-LogFile -Path $LogFile
$services = Get-Service | ? {$_.DisplayName -imatch "SQL Server.*$SQLInstance"}

Write-Host "-----------------------------------------------------------"
Write-Host "Start Refresh "

#Remove-Variable * -ErrorAction SilentlyContinue

Write-Host "Import Variables "
Get-Content "$Path\RefreshSQLSettingsold.txt" | Foreach-Object{
   $var = $_.Split('=')
   if ($var[0] -eq "ArrayPassword") {Write-Host $var[0] "= (masked)" }
   else {Write-Host $var[0] "=" $var[1] }
   New-Variable -Name $var[0] -Value $var[1]
}
$FullSQL = $InitiatorGroup + '\' + $SQLInstance
[string[]]$ToArray = $To -split ";"
[string[]]$GroupToArray = $GroupTo -split ";"

Connect-NSArray -SystemName $ArrayIP -UserName $ArrayUsername -Password $ArrayPassword 
StopSQL 

DeleteVolume $SQLAdmin 
DeleteVolume $SQLData 
DeleteVolume $SQLLog 
DeleteVolume $SQLIndex 
DeleteVolume $SQLArchive 
DeleteVolume $SQLPartitionFiles1 
DeleteVolume $SQLPartitionFiles2 
CloneVolume $ProdAdmin $SQLAdmin 
CloneVolume $ProdData $SQLData 
CloneVolume $ProdLog $SQLLog 
CloneVolume $ProdIndex $SQLIndex 
CloneVolume $ProdArchive $SQLArchive 
CloneVolume $ProdPartitionFiles1 $SQLPartitionFiles1 
CloneVolume $ProdPartitionFiles2 $SQLPartitionFiles2 

RefreshiSCSI
ConnectDisks
StartSQL
RunSQLScripts
Write-Host "Refresh Complete"
SendEmails

$Log | Disable-LogFile 

Remove-Variable * -ErrorAction SilentlyContinue
