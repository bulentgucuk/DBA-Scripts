﻿function StopSQL {
    #Shutdown SQL Services
    foreach($service in $services) {
        Write-Host "Stopping SQL service" $service.Name "then Sleep 10 seconds"
        Stop-Service -Force -Name $service.Name
        Start-Sleep -s 10
    }
}

function StartSQL {
    # Restart SQL Services
    foreach($service in $services) {
        if((Get-WmiObject Win32_Service -filter ("Name='"+$service.Name+"'")).StartMode -eq "Auto") {
            Write-Host "Starting SQL service" $service.Name "then Sleep 10 seconds"
            Start-Service -Name $service.Name
        }
    }
    Start-Sleep -s 10
}

function DeleteVolume ($CloneVolume) {
    if ($CloneVolume -ne "") {      
        ######################################
        # Find CloneVolume by Name
        ######################################
        Write-Host "Find Volume by Name:" $CloneVolume
        $uri = "https://" + $ArrayIP + ":5392/v1/volumes"
        $volume_list = Invoke-RestMethod -Uri $uri -Method Get -Header $header

        foreach ($volume_id in $volume_list.data.id){
	        $uri = "https://" + $ArrayIP + ":5392/v1/volumes/" + $volume_id
	        $volume = Invoke-RestMethod -Uri $uri -Method Get -Header $header
	
	        if ($volume.data.name -eq $CloneVolume){
		        $CloneVolume_id = $volume.data.id
	        }	
        }

        ######################################
        # Offline CloneVolume
        ######################################
        if ($CloneVolume_id -ne $null){
            Write-Host "Offline Volume:" $CloneVolume "(" $CloneVolume_id ")"
            $data = @{
	            online = "false"
                force = "true"
                volcoll_id = ""   #remove from volume collection
            }

            $body = convertto-json (@{ data = $data })
            $uri = "https://" + $ArrayIP + ":5392/v1/volumes/" + $CloneVolume_id
            $result = Invoke-RestMethod -Uri $uri -Method Put -Body $body -Header $header

            ######################################
            # Delete CloneVolume
            ######################################
            Write-Host "Delete Volume:" $CloneVolume "(" $CloneVolume_id ")"
            $uri = "https://" + $ArrayIP + ":5392/v1/volumes/" + $CloneVolume_id
            $result = Invoke-RestMethod -Uri $uri -Method Delete -Header $header
        }
    }
}

function CloneVolume ($ProdVolume, $CloneVolume) {
    if ($ProdVolume -ne "") {       
        ######################################
        # Find Most Recent Snapshots
        ######################################
        write-host "Get Most Recent Snapshots:" $ProdVolume
        $prod_array = @();
        $ProdVolume_array = @();
        $topsnapshot_array = @();

        $uri = "https://" + $ArrayIP + ":5392/v1/snapshot_collections/detail"
        $snaplist = Invoke-RestMethod -Uri $uri -Method get -Header $header
        $prod_array += $snaplist.data

        $ProdVolume_array = $prod_array | select snapshots_list, name, creation_time |where-object name -like $ProdVolumeCollection* | sort-object -Property creation_time -descending
        $topsnapshot_array = $ProdVolume_array[0].snapshots_list

        foreach ($el in $topsnapshot_array){
            ######################################
            # Get most recent ProdVolume Snapshot
            ######################################
            if ($el.vol_name -eq $ProdVolume){
                #write-host $el | format-table -autosize
                $Prod_snap_id = $el.snap_id

                ######################################
                # Create the Clone Volume
                ######################################
                write-host "Create Clone Volume from" $ProdVolumeCollection ":" $ProdVolume "to" $CloneVolumeCollection ":" $CloneVolume
                $data = @{
                    clone = "true"
	                name = $CloneVolume
	                base_snap_id = $Prod_snap_id
                    online = "true"
                }

                $body = convertto-json (@{ data = $data })
                $uri = "https://" + $ArrayIP + ":5392/v1/volumes"
                $result = Invoke-RestMethod -Uri $uri -Method Post -Body $body -Header $header
                #$result.data | select name,size,clone,online,parent_vol_name,id | format-table -autosize
                $CloneVolume_id = $result.data.id

                ######################################
                # Get CloneVolumeCollection id
                ######################################
                write-host "Get" $CloneVolumeCollection "id"
                $uri = "https://" + $ArrayIP + ":5392/v1/volume_collections"
                $volume_list = Invoke-RestMethod -Uri $uri -Method Get -Header $header
  
                foreach ($volume_id in $volume_list.data.id){
	                $uri = "https://" + $ArrayIP + ":5392/v1/volume_collections/" + $volume_id
	                $volume = Invoke-RestMethod -Uri $uri -Method Get -Header $header
	            
	                if ($volume.data.name -eq $CloneVolumeCollection){
		                $CloneVolumeCollection_id = $volume.data.id
	                }
                }

                ######################################
                # Add Volume to Vol Coll
                ######################################
                write-host "Add Volume" $CloneVolume "(" $CloneVolume_id ") to" $CloneVolumeCollection "(" $CloneVolumeCollection_id ")"
                $data = @{
                    volcoll_id = $CloneVolumeCollection_id
                }

                $body = convertto-json (@{ data = $data })
                $uri = "https://" + $ArrayIP + ":5392/v1/volumes/" + $CloneVolume_id
                $result = Invoke-RestMethod -Uri $uri -Method Put -Body $body -Header $header
                #$result.data | select name,size,clone,online,parent_vol_name | format-table -autosize

                ######################################
                # Get CloneVolume Access Control Records
                ######################################
                write-host "Get Access Control Records"
                $uri = "https://" + $ArrayIP + ":5392/v1/access_control_records/detail"
                $ACR_list = Invoke-RestMethod -Uri $uri -Method get -Header $header
                
                
                foreach ($volume_id in $ACR_list.data.id){
	                #write-host "Get Access Control Record" $volume_id
                    $uri = "https://" + $ArrayIP + ":5392/v1/access_control_records/" + $volume_id
	                $volume = Invoke-RestMethod -Uri $uri -Method Get -Header $header
	
	                if ($volume.data.vol_name -eq $CloneVolume){
		                $ACR_id = $volume.data.id
                        $IG_Name = $volume.data.initiator_group_name
                        $Vol_Name = $volume.data.vol_name
                        $vol_ID = $volume.data.vol_id
                        ######################################
                        # Delete CloneVolume Access Control Records 
                        ######################################
                        Write-Host "Delete Access Control Records" $IG_Name "(" $ACR_id ") for" $Vol_Name "(" $vol_ID ")"
                        $uri = "https://" + $ArrayIP + ":5392/v1/access_control_records/" + $ACR_id
                        $result = Invoke-RestMethod -Uri $uri -Method Delete -Header $header	                      
                    }	                       
                }

                ######################################
                # Get CloneVolume Initiator Group ID
                ######################################
                Write-Host "Get CloneVolume Initiator Group ID"
                $uri = "https://" + $ArrayIP + ":5392/v1/initiator_groups/detail"
                $IG_list = Invoke-RestMethod -Uri $uri -Method get -Header $header

                foreach ($volume_id in $IG_list.data.id){
	                #write-host "Get Initiator Group" $volume_id
                    $uri = "https://" + $ArrayIP + ":5392/v1/initiator_groups/" + $volume_id
	                $initiator_group = Invoke-RestMethod -Uri $uri -Method Get -Header $header

	                if ($initiator_group.data.name -eq $InitiatorGroup){
		                $IG_id = $initiator_group.data.id
                        $IG_Name = $initiator_group.data.name
                        write-host "Initiator Group" $IG_Name "(" $IG_id ")"
                        break
                    }
                }

                ######################################
                # Add CloneVolume Initiator Group
                ######################################
                write-host "Add CloneVolume Initiator Group" $IG_Name "(" $IG_id ") for" $CloneVolume "(" $CloneVolume_id ")"
                $data = @{
                    apply_to = "volume"
                    initiator_group_id = $IG_id
	                vol_id = $CloneVolume_id
                }

                $body = convertto-json (@{ data = $data })
                $uri = "https://" + $ArrayIP + ":5392/v1/access_control_records"
                $result = Invoke-RestMethod -Uri $uri -Method Post -Body $body -Header $header

                break
            }
        }
    }
}

function RefreshiSCSI {
    # Refresh iSCSI Targets
    Write-Host "Refreshing to find new targets"
    Refresh-Targets

    # Get Available Nimble Targets
    $NimbleTargets = Get-AvailableTargets | ? {$_.Target -notmatch "com.nimblestorage:control-"} | ? {$_.Target -match "com.nimblestorage"} | Sort-Object -Unique Target
    Write-Host "Found " $NimbleTargets.Count " Nimble targets"

    # Loop through each Nimble target and host IP and validate connections. If any are missing, execute iscsicli to connect and make persistent 
    Write-Host "Removing all old Nimble persistent iSCSI logins"
    foreach ($Login in Get-PersistentLogins | ? {$_.Target -match "com.nimblestorage"}) {
      if ($Login.Target -eq $null) {
        continue
      }
      iscsicli removepersistenttarget $Login.Initiator $Login.Target $Login.InitiatorPort $Login.TargetIP $Login.TargetPort | Out-Null
    }

    foreach ($Target in $NimbleTargets) {
      Write-Host "Connecting to " $Target.Target
      Connect-toIQN $Target.Target
    }
}

function ConnectDisks {
    # Wait 5 seconds for connections to finalize
    Write-Host "Rescanning for new drives"
    "rescan `n exit" | diskpart | out-null
    Start-Sleep -s 10

    # Get current set of Nimble sessions
    #$NimbleDisks = Get-EstablishedSessions | ? {$_.Target -match "com.nimblestorage"} | ? {$_.Target -match $env:COMPUTERNAME + "-" + $SQLInstance } | Select Target,TargetNice,Devices -Unique
    $NimbleDisks = Get-EstablishedSessions | Select Target,TargetNice,Devices -Unique

    # Loop Nimble Disks and make sure they are online and mount if not already mounted
    foreach ($NimbleDisk in $NimbleDisks) {
      Write-Host "Setting " $NimbleDisk.TargetNice " online"
      "select disk "+$NimbleDisk.Devices[0].DeviceNumber+"`n attributes disk clear readonly noerr`n online `n online disk" | diskpart | out-null
      $Disk = Get-WmiObject -Class Win32_DiskDrive | ? {$_.Caption -match "Nimble Server" -and $_.DeviceID -eq $NimbleDisk.Devices[0].LegacyName}
      $Partitions = Get-WmiObject -Query "ASSOCIATORS OF {$($Disk.Path.RelativePath)}" | ? {$_.__CLASS -eq "Win32_DiskPartition"}
      foreach ($Partition in $Partitions) {
	    $PathMount = "$Path\"+$NimbleDisk.TargetNice+"\"+$Partition.Index
	    if(Test-Path -Path $PathMount -PathType Container) {
	      mountvol $PathMount /d
	    }
	    else {
	      #New-Item $Path -ItemType Directory | Out-Null
	    }

  	    Write-Host "Mounting " $NimbleDisk.TargetNice " @ " $Path
	    "select disk "+$NimbleDisk.Devices[0].DeviceNumber+"`n select partition "+$($Partition.Index + 1)+"`n attributes volume clear readonly noerr`n attributes volume clear hidden noerr`n attributes volume clear shadowcopy noerr`n assign mount="+$Path | diskpart
	    "select disk "+$NimbleDisk.Devices[0].DeviceNumber+"`n select partition "+$($Partition.Index + 1)+"`n attributes volume clear readonly noerr`n attributes volume clear hidden noerr`n attributes volume clear shadowcopy noerr`n assign mount="+$Path | diskpart
	    chkdsk /x $Path | out-null
      }
    }
    Write-Host "Sleep 30 Seconds"
    Start-Sleep -s 30
}

function RunSQLScripts {
    #If environment doesn't use the script have a placeholder file
    Write-Host "Restore AppMgmt Database"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Path\Scripts\AppMgmtRestore.sql" -querytimeout 600 -verbose
    Write-Host "Run Cleanup Script"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Path\Scripts\CleanupScript.sql" -querytimeout 600 -verbose
    Write-Host "Restore Security Changes - SAH\QA"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Path\Scripts\Security.sql" -querytimeout 600 -verbose 
    Write-Host "Restore Security Changes - DEV"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Path\Scripts\Security_DEV.sql" -querytimeout 600 -verbose 
    Write-Host "Restore Security Changes - MKTG"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Path\Scripts\Security_MKTG.sql" -querytimeout 600 -verbose 
    Write-Host "Restore Security Changes - AutomationUser"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Path\Scripts\AutomationUser.sql" -querytimeout 600 -verbose 
    Write-Host "Reseed Customer"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Path\Scripts\Reseed.sql" -querytimeout 600 -verbose
    Write-Host "Set Database Properties"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Path\Scripts\Database_Properties.sql" -querytimeout 600 -verbose
    Write-Host "Owner Fix"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Path\Scripts\Owner.sql" -querytimeout 600 -verbose 
    Write-Host "Orphan User Fix"
    $ErrorCount = $error.count
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Path\Scripts\OrphanFix.sql" -querytimeout 600 -verbose -ErrorAction SilentlyContinue
    #If the orphan fix can't fix the issue it reports a false error.
    if ($ErrorCount -eq 0 -and $error.count -ne 0) {
        Write-Host "Clear Orphan User False Error"
        $error.Clear()
    }
    Write-Host "Replication Fix"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Path\Scripts\Replication.sql" -querytimeout 600 -verbose    

    if ($DW -eq "true") {
      Start-Sleep -s 10
      #Update DDL and DML for DEV BI Environment
      Write-Host "Update DDL and DML for $SQLInstance Environment Specific requirements"
      Get-ChildItem -path "$Path\Scripts\OrderedObjects" -Filter "*.sql"| %{invoke-sqlcmd -InputFile $_.FullName -ServerInstance $FullSQL}
      foreach ($f in Get-ChildItem -path "$Path\Scripts\OrderedObjects" -Filter *.sql | sort-object) 
      {
        $out = "$Path\Scripts\OrderedObjects\" + $f.name.split(".")[0] + ".txt" ;
        write-host $f
        invoke-sqlcmd –ServerInstance $FullSQL -InputFile $f.fullname | format-table | out-file -filePath $out
      }
      Invoke-SqlCmd -InputFile "$Path\Scripts\biteam.sql" -ServerInstance $FullSQL -querytimeout 600 -verbose
    }
}

function SendEmails {
    if ($error.count -eq 0) {
	    [string]$Subject = "Success: $SQLInstance SQL Scripts Applied"
	    [string]$EmailBody = "SQL Script Refresh Complete"
	    
	    $email = @{
		    From = $From
		    To = $GroupToArray
		    Subject = $Subject 
		    SMTPServer = $SMTP
		    Body = $EmailBody
	    }

        #Notify XYZ Group the refresh was completed with success (As long as it is not a test/dba manual run) 
        if ($Test -eq "false") {	    
            Write-Host "Sending Group Email to " $GroupTo
            #send-mailmessage @email 
        }
	    $EmailBody = (Get-Content -Path $LogFile -raw)
    }
    Else {
	    [string]$EmailBody = $error
	    [string]$Subject = "Failure: $SQLInstance Refresh Error"
    } 

    Write-Host "Sending Email to " $To
    #dba notify
    $email = @{
      From = $From
      To = $ToArray
      Subject = $Subject 
      SMTPServer = $SMTP
      Body = $EmailBody
    }
    send-mailmessage @email
}

####MAIN###
$error.Clear()
cls
#Import Modules/Cmdlets
#https://gallery.technet.microsoft.com/scriptcenter/Enhanced-Script-Logging-27615f85
Import-Module PowerShellLogging 
#Import-Module Nimble
Import-Module 'sqlps' –DisableNameChecking
. ("C:\Windows\System32\WindowsPowerShell\v1.0\Modules\Nimble\iSCSI_Cmdlets.ps1")

$Path  = "c:\nimble" #[System.Environment]::CurrentDirectory
$LogFile = "$Path\Logs\$(get-date -f yyyy-MM-dd).log"
$Log = Enable-LogFile -Path $LogFile
$services = Get-Service | ? {$_.DisplayName -imatch "SQL Server.*$SQLInstance"}

Write-Host "-----------------------------------------------------------"
Write-Host "Start Refresh "

Write-Host "Import Variables "
Get-Content "$Path\RefreshSQLSettings.txt" | Foreach-Object{
   $var = $_.Split('=')
   if ($var[0] -eq "ArrayPassword") {Write-Host $var[0] "= (masked)" }
   else {Write-Host $var[0] "=" $var[1] }
   New-Variable -Name $var[0] -Value $var[1]
}
$FullSQL = $InitiatorGroup + '\' + $SQLInstance
[string[]]$ToArray = $To -split ";"
[string[]]$GroupToArray = $GroupTo -split ";"

<#StopSQL 

###########################
# Enable HTTPS
###########################
Write-Host "Enable HTTPS "
[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}

###########################
# Get Token
###########################
Write-Host "Get Token "
$data = @{
    username = $ArrayUsername
	password = $ArrayPassword
}

$body = convertto-json (@{ data = $data })

$uri = "https://" + $ArrayIP + ":5392/v1/tokens"
$token = Invoke-RestMethod -Uri $uri -Method Post -Body $body
$token = $token.data.session_token
$header = @{ "X-Auth-Token" = $token }



DeleteVolume $CloneVolume1 
DeleteVolume $CloneVolume2 
DeleteVolume $CloneVolume3 
DeleteVolume $CloneVolume4 
DeleteVolume $CloneVolume5 
DeleteVolume $CloneVolume6 
DeleteVolume $CloneVolume7 
DeleteVolume $CloneVolume8 
DeleteVolume $CloneVolume9 
CloneVolume $ProdVolume1 $CloneVolume1 
CloneVolume $ProdVolume2 $CloneVolume2
CloneVolume $ProdVolume3 $CloneVolume3 
CloneVolume $ProdVolume4 $CloneVolume4 
CloneVolume $ProdVolume5 $CloneVolume5 
CloneVolume $ProdVolume6 $CloneVolume6 
CloneVolume $ProdVolume7 $CloneVolume7 
CloneVolume $ProdVolume8 $CloneVolume8 
CloneVolume $ProdVolume9 $CloneVolume9 


RefreshiSCSI
ConnectDisks
StartSQL

Write-Host "Sleep 30 Seconds"
Start-Sleep -s 30
#>

Write-Host "RunSQLScripts"
RunSQLScripts
Write-Host "Refresh Complete"
SendEmails

$Log | Disable-LogFile 
Remove-Variable * -ErrorAction SilentlyContinue
