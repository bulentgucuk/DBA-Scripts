﻿function SendNotification {
    
    [string]$Subject = "$SQLInstance "
    if ($RefreshObject -eq "SQL") {
        [string]$Detail = "SQL "
    }
    else
    {
        [string]$Detail = ""
    }

    if ($error.count -eq 0) {	    
        $Subject = $Subject + $Detail + "Refresh Successful"
	    [string]$EmailBody = "Success"  #[string]$EmailBody = (Get-Content -Path $LogFile -raw)
        [string]$SlackBotState = $SlackBotSuccessState
    }
    Else {
	    $Subject = $Subject + $Detail + "Refresh Error"
        [string]$EmailBody = "Failure" #[string]$EmailBody = $error
        [string]$SlackBotState = $SlackBotFailureState
    }
        
    Write-Host $Subject

    if ($SendEmail -eq "true") {
        Write-Host "Sending Email to " $To
        $email = @{
              From = $From
              To = $ToArray
              Subject = $Subject 
              SMTPServer = $SMTP
              Body = $EmailBody
        }
        send-mailmessage @email
    }

    if ($SendSlack -eq "true") {
        $payload = @{ 
            "channel" = $SlackChannel 
 	        "icon_emoji" = ":" + $SlackBotIcon + ":"
 	        "text" = ":" + $SlackBotState + ": " + $Subject
 	        "username" = $FullSQL 
        } 
        Invoke-WebRequest -Uri $SlackHook -Method "POST" -Body (ConvertTo-Json -Compress -InputObject $payload) 
    }
}

####MAIN###

SendNotification
