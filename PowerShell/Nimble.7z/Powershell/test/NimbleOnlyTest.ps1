﻿####MAIN###
cls
#Remove-Variable * -ErrorAction SilentlyContinue
#Import Modules/Cmdlets
#https://gallery.technet.microsoft.com/scriptcenter/Enhanced-Script-Logging-27615f85
Import-Module PowerShellLogging 
#Import-Module Nimble
import-module "C:\Windows\System32\WindowsPowerShell\v1.0\Modules\Nimble_PowerShell_ToolKit_1.0.0\NimblePowerShellToolkit"
Import-Module 'sqlps' –DisableNameChecking
. ("C:\Windows\System32\WindowsPowerShell\v1.0\Modules\Nimble_iSCSI\iSCSI_Cmdlets.ps1")

$Path = Split-Path $MyInvocation.MyCommand.Path
$PathNimble = "$Path\NimbleTest.ps1"
$PathSQL = "$Path\SQL.ps1"
$Parent = (get-item $Path).parent.FullName
$LogFile = $Parent + "\Logs\$(get-date -f yyyy-MM-dd).log"
$Log = Enable-LogFile -Path $LogFile

Write-Host "-----------------------------------------------------------"
Write-Host "Start Refresh "
Write-Host "Path:" $Path
Write-Host "PathNimble:" $PathNimble
Write-Host "PathSQL:" $PathSQL
Write-Host "LogFile:" $LogFile
Write-Host "Parent:" $Parent

Write-Host "Import Variables "
Get-Content "$Path\RefreshSettings.txt" | Foreach-Object{
   $var = $_.Split('=')
   if ($var[0] -eq "ArrayPassword") {Write-Host $var[0] "= (masked)" }
   else {Write-Host $var[0] "=" $var[1].TrimEnd() }
   New-Variable -Name $var[0] -Value $var[1].TrimEnd() -Force
}
[string[]]$ToArray = $To -split ";"

if ($Cluster -eq "") { 
   $FullSQL = $InitiatorGroup + '\' + $SQLInstance
}
else {
    $FullSQL = $Cluster + '\' + $SQLInstance
}


#StopSQL 

Write-Host "Start Drive Refresh"
Invoke-Expression $PathNimble
Write-Host "Finish Drive Refresh"

#StartSQL

#Write-Host "Start SQL Scripts"
#Invoke-Expression $PathSQL
#Write-Host "Finish SQL Scripts"

#Write-Host "Refresh Complete"

#SendEmails

#$Log | Disable-LogFile 

#Remove-Variable * -ErrorAction SilentlyContinue
