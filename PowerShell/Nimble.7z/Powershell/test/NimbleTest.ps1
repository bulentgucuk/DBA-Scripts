﻿
function DeleteVolume ($CloneVolume) {
    if ($CloneVolume -ne "") {      
        ######################################
        # Find CloneVolume by Name
        ######################################
        Write-Host Offline $CloneVolume
        Set-NSVolume -name $CloneVolume -online 0 -volcoll_id '' -ErrorAction SilentlyContinue
        Write-Host Remove $CloneVolume
        Remove-NSVolume -name $CloneVolume -ErrorAction SilentlyContinue
    }
}

function CloneVolume ($ProdVolume, $CloneVolume) {
    if ($ProdVolume -ne "") {       
        ######################################
        # Find Most Recent Snapshots
        ######################################    
        $vollcol_id = $(Get-NSVolumeCollection -name $CloneVolumeCollection).id
        Write-Host "Get VolumeCollectionID:" $CloneVolumeCollection ":Coll" $VollCol_ID

        $ProdSnapshot = $(Get-NSsnapshot -vol_name $ProdVolume).id[0]
        write-host "Latest Volume:SnapshotID:" $ProdVolume ":" $ProdSnapshot  

        New-NSVolume -name $CloneVolume -clone 1 -base_snap_id $ProdSnapshot -size 1
        write-host "Clone Latest Snapshot:" $ProdSnapshot  

        $VolID = $(Get-NSVolume -name $CloneVolume).id
        write-host "New Volume ID:" $VolID

        $Acl_ID = $(Get-NSVolume -name $CloneVolume).access_control_records.acl_id
        write-host "Remove $ProdVolume AccessControlRecord:" $Acl_ID
        Remove-NSAccessControlRecord -id $Acl_ID

        $VolIG = $(Get-NSInitiatorGroup -name $InitiatorGroup).id
        write-host "Add $CloneVolume InitiatorGroupID:" $VolIG
        New-NSAccessControlRecord -vol_id $VolID -initiator_group_id $VolIG

        write-host "CloneVolumeCollection " $CloneVolume : $CloneVolumeCollection
        Set-NSVolume -name $CloneVolume -volcoll_id $VollCol_ID -online 1
        write-host "SetVolume Vars: -volcoll_id $VollCol_ID -online 1"
    }
}

function RefreshiSCSI {
    # Refresh iSCSI Targets
    Write-Host "Refreshing to find new targets"
    Refresh-Targets

    # Get Available Nimble Targets
    $NimbleTargets = Get-AvailableTargets | ? {$_.Target -notmatch "com.nimblestorage:control-"} | ? {$_.Target -match "com.nimblestorage"} | Sort-Object -Unique Target
    Write-Host "Found " $NimbleTargets.Count " Nimble targets"

    # Loop through each Nimble target and host IP and validate connections. If any are missing, execute iscsicli to connect and make persistent 
    Write-Host "Removing all old Nimble persistent iSCSI logins"
    foreach ($Login in Get-PersistentLogins | ? {$_.Target -match "com.nimblestorage"}) {
      if ($Login.Target -eq $null) {
        continue
      }
      iscsicli removepersistenttarget $Login.Initiator $Login.Target $Login.InitiatorPort $Login.TargetIP $Login.TargetPort | Out-Null
    }

    foreach ($Target in $NimbleTargets) {
      Write-Host "Connecting to " $Target.Target
      Connect-toIQN $Target.Target
    }
}

function ConnectDisks {
    # Wait 5 seconds for connections to finalize
    Write-Host "Rescanning for new drives"
    "rescan `n exit" | diskpart | out-null
    Start-Sleep -s 10

    # Get current set of Nimble sessions
    #$NimbleDisks = Get-EstablishedSessions | ? {$_.Target -match "com.nimblestorage"} | ? {$_.Target -match $env:COMPUTERNAME + "-" + $SQLInstance } | Select Target,TargetNice,Devices -Unique
    $NimbleDisks = Get-EstablishedSessions | Select Target,TargetNice,Devices -Unique

    # Loop Nimble Disks and make sure they are online and mount if not already mounted
    foreach ($NimbleDisk in $NimbleDisks) {
      Write-Host "Setting " $NimbleDisk.TargetNice " online"
      "select disk "+$NimbleDisk.Devices[0].DeviceNumber+"`n attributes disk clear readonly noerr`n online `n online disk" | diskpart | out-null
      $Disk = Get-WmiObject -Class Win32_DiskDrive | ? {$_.Caption -match "Nimble Server" -and $_.DeviceID -eq $NimbleDisk.Devices[0].LegacyName}
      $Partitions = Get-WmiObject -Query "ASSOCIATORS OF {$($Disk.Path.RelativePath)}" | ? {$_.__CLASS -eq "Win32_DiskPartition"}
      foreach ($Partition in $Partitions) {
	    $PathMount = "$Path\"+$NimbleDisk.TargetNice+"\"+$Partition.Index
	    if(Test-Path -Path $PathMount -PathType Container) {
	      mountvol $PathMount /d
	    }
	    else {
	      #New-Item $Path -ItemType Directory | Out-Null
	    }

  	    Write-Host "Mounting " $NimbleDisk.TargetNice " @ " $Path
	    "select disk "+$NimbleDisk.Devices[0].DeviceNumber+"`n select partition "+$($Partition.Index + 1)+"`n attributes volume clear readonly noerr`n attributes volume clear hidden noerr`n attributes volume clear shadowcopy noerr`n assign mount="+$Path | diskpart
	    "select disk "+$NimbleDisk.Devices[0].DeviceNumber+"`n select partition "+$($Partition.Index + 1)+"`n attributes volume clear readonly noerr`n attributes volume clear hidden noerr`n attributes volume clear shadowcopy noerr`n assign mount="+$Path | diskpart
	    chkdsk /x $Path | out-null
      }
    }

    Start-Sleep -s 30
}


####MAIN###

$ArrayPasswordSecure = ConvertTo-SecureString –String $ArrayPassword –AsPlainText -Force
$Credential = New-Object –TypeName System.Management.Automation.PSCredential –ArgumentList $ArrayUsername, $ArrayPasswordSecure
Connect-NSGroup –Group $ArrayIP -Credential $Credential 


#Write-Host Offline $CloneVolume1
#Set-NSVolume -name $CloneVolume1 -online 0 -volcoll_id ''
#Write-Host Remove $CloneVolume1
#Remove-NSVolume -name $CloneVolume1

#$vollcol_id = $(Get-NSVolumeCollection -name $CloneVolumeCollection).id
#Write-Host "Get Volume CollectionID:" $CloneVolumeCollection ":Coll" $vollcol_id

#Write-Host Get Latest Snapshot $ProdVolume1
#$ProdSnapshot = $(Get-NSsnapshot -vol_name $ProdVolume1).id[0]
#write-host "Latest Volume:SnapshotID:" $ProdVolume1 ":" $ProdSnapshot  

#New-NSVolume -name $CloneVolume1 -clone 1 -base_snap_id $ProdSnapshot -size 1
#write-host "Clone Latest Snapshot:" $ProdSnapshot  

#$Volid = $(Get-NSVolume -name $CloneVolume1).id
#write-host "New Volume ID:" $Volid

#$acl_id = $(Get-NSVolume -name $CloneVolume1).access_control_records.acl_id
#write-host "Remove AccessControlRecord:" $acl_id
#Remove-NSAccessControlRecord -id $acl_id

#$VolIG = $(Get-NSInitiatorGroup -name $InitiatorGroup).id
#write-host "Get InitiatorGroup id:" $VolIG
#New-NSAccessControlRecord -vol_id $Volid -initiator_group_id $VolIG

#write-host "CloneVolumeCollection " $CloneVolume1 : $CloneVolumeCollection
#Set-NSVolume -name $CloneVolume1 -volcoll_id $vollcol_id -online 1
#write-host "SetVolume Vars: -volcoll_id $vollcol_id -online 1"

#
#Remove-Variable * -ErrorAction SilentlyContinue

DeleteVolume $CloneVolume1 
CloneVolume $ProdVolume1 $CloneVolume1 

exit


DeleteVolume $CloneVolume1 
DeleteVolume $CloneVolume2 
DeleteVolume $CloneVolume3 
DeleteVolume $CloneVolume4 
DeleteVolume $CloneVolume5 
DeleteVolume $CloneVolume6 
DeleteVolume $CloneVolume7 
DeleteVolume $CloneVolume8 
DeleteVolume $CloneVolume9 
CloneVolume $ProdVolume1 $CloneVolume1 
CloneVolume $ProdVolume2 $CloneVolume2
CloneVolume $ProdVolume3 $CloneVolume3 
CloneVolume $ProdVolume4 $CloneVolume4 
CloneVolume $ProdVolume5 $CloneVolume5 
CloneVolume $ProdVolume6 $CloneVolume6 
CloneVolume $ProdVolume7 $CloneVolume7 
CloneVolume $ProdVolume8 $CloneVolume8 
CloneVolume $ProdVolume9 $CloneVolume9 

Disconnect-NSGroup

RefreshiSCSI
ConnectDisks

