﻿####This script is used to replace prod values with dev/qa values####
####ie. Clean the REPL scripts###

####MAIN###
cls
$error.Clear()

$Path = Split-Path $MyInvocation.MyCommand.Path
$PathNimble = "$Path\Nimble.ps1"
$PathSQL = "$Path\SQL.ps1"
$PathSQLReplication = "$Path\SQLReplication.ps1"
$PathNotify = "$Path\Notify.ps1"
$Parent = (get-item $Path).parent.FullName
$LogFile = $Parent + "\Logs\"+ [DateTime]::Now.ToString("yyyyMMdd-HHmmss") + ".log"
$Log = Enable-LogFile -Path $LogFile
$RefreshObject = "REPLICATION"

Write-Host "-----------------------------------------------------------"
Write-Host "Start Refresh "
Write-Host "Path:" $Path
Write-Host "PathNimble:" $PathNimble
Write-Host "PathSQL:" $PathSQL
Write-Host "PathSQLReplication:" $PathSQLReplication
Write-Host "PathNotify:" $PathNotify
Write-Host "LogFile:" $LogFile
Write-Host "Parent:" $Parent
Write-Host "Refresh:" $RefreshObject

Write-Host "Import Variables "
Get-Content "$Path\RefreshSettings.txt" | Foreach-Object{
   $var = $_.Split('=')
   if ($var[0] -eq "ArrayPassword") {Write-Host $var[0] "= (masked)" }
   else {Write-Host $var[0] "=" $var[1].TrimEnd() }
   New-Variable -Name $var[0] -Value $var[1].TrimEnd() -Force
}


$ReplAddFile = "c:\nimble\SQLScripts\REPL_Add.sql"
$ReplDropFile = "c:\nimble\SQLScripts\REPL_Drop.sql"

if ($SQLInstance -eq "DEVSQL") { 
    (Get-Content $ReplAddFile).replace('SQL14PROD03\PRODODS', 'VIA12DEVODS01\DEVODS') | Set-Content $ReplAddFile
    (Get-Content $ReplAddFile).replace('SQL14PROD01\PRODSQL', 'VIA12DEVSQL01\DEVSQL') | Set-Content $ReplAddFile
    (Get-Content $ReplAddFile).replace('NT SERVICE\MSSQL$PRODSQL', 'NT SERVICE\MSSQL$DEVSQL') | Set-Content $ReplAddFile
    (Get-Content $ReplAddFile).replace('NT SERVICE\SQLAgent$PRODSQL', 'NT SERVICE\SQLAgent$DEVSQL') | Set-Content $ReplAddFile

    (Get-Content $ReplAddFile).replace('SQL14PROD03\PRODODS', 'VIA12DEVODS01\DEVODS') | Set-Content $ReplAddFile
    (Get-Content $ReplAddFile).replace('SQL14PROD01\PRODSQL', 'VIA12DEVSQL01\DEVSQL') | Set-Content $ReplAddFile
    (Get-Content $ReplAddFile).replace('NT SERVICE\MSSQL$PRODSQL', 'NT SERVICE\MSSQL$DEVSQL') | Set-Content $ReplAddFile
    (Get-Content $ReplAddFile).replace('NT SERVICE\SQLAgent$PRODSQL', 'NT SERVICE\SQLAgent$DEVSQL') | Set-Content $ReplAddFile
    (Get-Content $ReplAddFile).replace('@subscriber_password = null', '@subscriber_password = ''qaol^&67''') | Set-Content $ReplAddFile
    (Get-Content $ReplAddFile).replace('BOULDER\SVC-SQL14ProdODS', 'BOULDER\SVC-SQL14DEVODS') | Set-Content $ReplAddFile
    (Get-Content $ReplAddFile).replace('BOULDER\SVC-SQL14ProdSQL', 'boulder\SVC-SQL14DEVSQL') | Set-Content $ReplAddFile
    (Get-Content $ReplAddFile).replace('@sync_type = N''automatic''', '@sync_type = N''replication support only''') | Set-Content $ReplAddFile

    (Get-Content $ReplDropFile).replace('SQL14PROD03\PRODODS', 'VIA12DEVODS01\DEVODS') | Set-Content $ReplDropFile
    (Get-Content $ReplDropFile).replace('SQL14PROD01\PRODSQL', 'VIA12DEVSQL01\DEVSQL') | Set-Content $ReplDropFile
}

if ($SQLInstance -eq "QASQL") { 
    (Get-Content $ReplAddFile).replace('SQL14PROD03\PRODODS', 'VIA12QAODS02\QAODS') | Set-Content $ReplAddFile
    (Get-Content $ReplAddFile).replace('SQL14PROD01\PRODSQL', 'VIA12QASQL01\QASQL') | Set-Content $ReplAddFile
    (Get-Content $ReplAddFile).replace('NT SERVICE\MSSQL$PRODSQL', 'NT SERVICE\MSSQL$QASQL') | Set-Content $ReplAddFile
    (Get-Content $ReplAddFile).replace('NT SERVICE\SQLAgent$PRODSQL', 'NT SERVICE\SQLAgent$QASQL') | Set-Content $ReplAddFile

    (Get-Content $ReplAddFile).replace('SQL14PROD03\PRODODS', 'VIA12QAODS02\QAODS') | Set-Content $ReplAddFile
    (Get-Content $ReplAddFile).replace('SQL14PROD01\PRODSQL', 'VIA12QASQL01\QASQL') | Set-Content $ReplAddFile
    (Get-Content $ReplAddFile).replace('NT SERVICE\MSSQL$PRODSQL', 'NT SERVICE\MSSQL$QASQL') | Set-Content $ReplAddFile
    (Get-Content $ReplAddFile).replace('NT SERVICE\SQLAgent$PRODSQL', 'NT SERVICE\SQLAgent$QASQL') | Set-Content $ReplAddFile
    (Get-Content $ReplAddFile).replace('@subscriber_password = null', '@subscriber_password = ''qaol^&67''') | Set-Content $ReplAddFile
    (Get-Content $ReplAddFile).replace('BOULDER\SVC-SQL14ProdODS', 'BOULDER\SVC-SQL14QAODS') | Set-Content $ReplAddFile
    (Get-Content $ReplAddFile).replace('BOULDER\SVC-SQL14ProdSQL', 'boulder\SVC-SQL14QASQL') | Set-Content $ReplAddFile
    (Get-Content $ReplAddFile).replace('@sync_type = N''automatic''', '@sync_type = N''replication support only''') | Set-Content $ReplAddFile

    (Get-Content $ReplDropFile).replace('SQL14PROD03\PRODODS', 'VIA12QAODS02\QAODS') | Set-Content $ReplDropFile
    (Get-Content $ReplDropFile).replace('SQL14PROD01\PRODSQL', 'VIA12QASQL01\QASQL') | Set-Content $ReplDropFile

}


(Get-Content $ReplAddFile).replace('exec [AgentInfo].sys.sp_addqreader_agent', '--exec [AgentInfo].sys.sp_addqreader_agent') | Set-Content $ReplAddFile
(Get-Content $ReplAddFile).replace('exec [AppMgmt].sys.sp_addqreader_agent', '--exec [AppMgmt].sys.sp_addqreader_agent') | Set-Content $ReplAddFile
(Get-Content $ReplAddFile).replace('exec [Email].sys.sp_addqreader_agent', '--exec [Email].sys.sp_addqreader_agent') | Set-Content $ReplAddFile
(Get-Content $ReplAddFile).replace('exec [Keywords].sys.sp_addqreader_agent', '--exec [Keywords].sys.sp_addqreader_agent') | Set-Content $ReplAddFile
(Get-Content $ReplAddFile).replace('exec [MMS].sys.sp_addqreader_agent', '--exec [MMS].sys.sp_addqreader_agent') | Set-Content $ReplAddFile
(Get-Content $ReplAddFile).replace('exec [SAH].sys.sp_addqreader_agent', '--exec [SAH].sys.sp_addqreader_agent') | Set-Content $ReplAddFile
(Get-Content $ReplAddFile).replace('exec [SAHCMS].sys.sp_addqreader_agent', '--exec [SAHCMS].sys.sp_addqreader_agent') | Set-Content $ReplAddFile
(Get-Content $ReplAddFile).replace('exec [SAHCMSV2].sys.sp_addqreader_agent', '--exec [SAHCMSV2].sys.sp_addqreader_agent') | Set-Content $ReplAddFile
(Get-Content $ReplAddFile).replace('exec [SAHForum].sys.sp_addqreader_agent', '--exec [SAHForum].sys.sp_addqreader_agent') | Set-Content $ReplAddFile
(Get-Content $ReplAddFile).replace('exec [SAHSelect].sys.sp_addqreader_agent', '--exec [SAHSelect].sys.sp_addqreader_agent') | Set-Content $ReplAddFile
(Get-Content $ReplAddFile).replace('exec [SAHSelectLog].sys.sp_addqreader_agent', '--exec [SAHSelectLog].sys.sp_addqreader_agent') | Set-Content $ReplAddFile
(Get-Content $ReplAddFile).replace('exec [Segmentation].sys.sp_addqreader_agent', '--exec [Segmentation].sys.sp_addqreader_agent') | Set-Content $ReplAddFile
(Get-Content $ReplAddFile).replace('exec [SitePref].sys.sp_addqreader_agent', '--exec [SitePref].sys.sp_addqreader_agent') | Set-Content $ReplAddFile
(Get-Content $ReplAddFile).replace('exec [SystemLogging2].sys.sp_addqreader_agent', '--exec [SystemLogging2].sys.sp_addqreader_agent') | Set-Content $ReplAddFile

