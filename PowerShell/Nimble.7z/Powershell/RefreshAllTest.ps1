﻿function StopSQL {
    #Shutdown SQL Services

    if ($Cluster -eq "") { 
        $services = Get-Service | ? {$_.DisplayName -imatch "SQL Server.*$SQLInstance"}
        foreach($service in $services) {
            Write-Host "Stopping SQL service" $service.Name
            #Stop-Service -Force -Name $service.Name
            Start-Sleep -s 10    
        }
    }
    else {

        $ClusterResource = Get-ClusterResource -Cluster $Cluster | Where-Object {$_.Name -like "*($SQLInstance)"} 
        #write-host $ClusterResource
        #Get-ClusterResource -Cluster $Cluster | Where-Object {$_.Name -like "*($SQLInstance)"} |Sort-Object -Property OwnerGroup #| Select $_.Name, $_.State 
 
        foreach($ClusterResources in $ClusterResource) {
            #write-host "name: " $ClusterResources.Name "state: " $ClusterResources.State
            if ($ClusterResources.State -eq "Online") {
                Write-Host "Stopping SQL service: " $ClusterResources.Name
                #Stop-ClusterResource -Cluster $Cluster -Name $ClusterResources.Name            
            } 
        }
    }
    Start-Sleep -s 60
}

function StartSQL {
    # Restart SQL Services

    if ($Cluster -eq "") { 
        $services = Get-Service | ? {$_.DisplayName -imatch "SQL Server.*$SQLInstance"}
        foreach($service in $services) {
            if((Get-WmiObject Win32_Service -filter ("Name='"+$service.Name+"'")).StartMode -eq "Auto") {
            Write-Host "Starting SQL service " $service.Name
            #Start-Service -Name $service.Name
            }
        }   
    }
    else {
        $ClusterResource = Get-ClusterResource -Cluster $Cluster | 
                        Where-Object {$_.Name -like "*($SQLInstance)"}

        foreach($ClusterResources in $ClusterResource) {
            #write-host " name: " $ClusterResources.Name " current state: " $ClusterResources.State
            if ($ClusterResources.State -ne "Online") {
                Write-Host "Starting SQL service" $ClusterResources.Name
                #Start-ClusterResource -Cluster $Cluster -Name $ClusterResources.Name            
            } 
        }
    }
    Start-Sleep -s 90
}


####MAIN###
cls
$error.Clear()

#Import Modules/Cmdlets C:\Windows\System32\WindowsPowerShell\v1.0\Modules
#https://gallery.technet.microsoft.com/scriptcenter/Enhanced-Script-Logging-27615f85
Import-Module PowerShellLogging 

$Path = Split-Path $MyInvocation.MyCommand.Path
$PathNimble = "$Path\Nimble.ps1"
$PathSQL = "$Path\SQL.ps1"
$PathSQLReplication = "$Path\SQLReplication.ps1"
$PathNotify = "$Path\Notify.ps1"
$Parent = (get-item $Path).parent.FullName
$LogFile = $Parent + "\Logs\"+ [DateTime]::Now.ToString("yyyyMMdd-HHmmss") + ".log"
$Log = Enable-LogFile -Path $LogFile
$RefreshObject = "ALL"

Write-Host "-----------------------------------------------------------"
Write-Host "Start Refresh "
Write-Host "Path:" $Path
Write-Host "PathNimble:" $PathNimble
Write-Host "PathSQL:" $PathSQL
Write-Host "PathSQLReplication:" $PathSQLReplication
Write-Host "PathNotify:" $PathNotify
Write-Host "LogFile:" $LogFile
Write-Host "Parent:" $Parent
Write-Host "Refresh:" $RefreshObject

Write-Host "Import Variables "
Get-Content "$Path\RefreshSettings.txt" | Foreach-Object{
   $var = $_.Split('=')
   if ($var[0] -eq "ArrayPassword") {Write-Host $var[0] "= (masked)" }
   else {Write-Host $var[0] "=" $var[1].TrimEnd() }
   New-Variable -Name $var[0] -Value $var[1].TrimEnd() -Force
}
[string[]]$ToArray = $To -split ";"

if ($Cluster -eq "") { 
   $FullSQL = $InitiatorGroup + '\' + $SQLInstance
}
else {
    $FullSQL = $Cluster + '\' + $SQLInstance
}

Write-Host "-----------------------------------------------------------"
Write-Host "FullSQL:" $FullSQL
Write-Host "SendEmail:" $SendEmail
Write-Host "SendSlack:" $SendSlack
Write-Host "SlackHook:" $SlackHook
Write-Host "SlackChannel:" $SlackChannel
Write-Host "-----------------------------------------------------------"
$Log | Disable-LogFile 
