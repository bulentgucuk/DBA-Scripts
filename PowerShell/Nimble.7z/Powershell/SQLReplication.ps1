﻿function RunSQLScripts {
    #If environment doesn't use the script have a placeholder file
    Write-Host "Replication Cleanup"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Parent\SQLScripts\REPL_Cleanup.sql" -querytimeout 600 -verbose
    Start-Sleep -s 30
    Write-Host "Replication Drop"
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Parent\SQLScripts\REPL_Drop.sql" -querytimeout 600 -verbose

    if ($RefreshObject -eq "ALL" -or $RefreshObject -eq "SQL") {
        Write-Host "Restore AppMgmt Database"
        Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Parent\SQLScripts\AppMgmtRestore.sql" -querytimeout 600 -verbose
    }

    Write-Host "Replication Add"
    Start-Sleep -s 30
    Invoke-SqlCmd -ServerInstance $FullSQL -InputFile "$Parent\SQLScripts\REPL_Add.sql" -querytimeout 600 -verbose    
}


####MAIN###
Import-Module sqlps –DisableNameChecking
RunSQLScripts
